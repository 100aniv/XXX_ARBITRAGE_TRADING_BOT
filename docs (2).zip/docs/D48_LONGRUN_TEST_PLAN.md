# D48: 롱런 테스트 플랜 (1시간 / 4시간 / 12시간 / 24시간)

**작성일:** 2025-11-17  
**상태:** ✅ 완료 (플랜 문서)

---

## 📋 Executive Summary

D48에서 구현한 **실 REST 주문/취소 + 레이트리밋/재시도**를 검증하기 위한 **롱런 테스트 플랜**입니다.

이 문서는 **플랜과 가이드만 제공**하며, 실제 실행은 사용자가 수동으로 진행합니다.

---

## 🏗️ 테스트 계층 구조 (D37~D48)

```
D37-D42: 기초 구조
├── D37: ArbitrageEngine (신호 생성)
├── D42: Exchange Adapter (거래소 인터페이스)
└── D42: PaperExchange (시뮬레이션)

D43-D45: 엔진 & 루프
├── D43: LiveRunner (메인 루프)
├── D44: RiskGuard (거래 검증)
└── D45: 수량/스프레드 계산

D46: Read-Only 모드
├── Upbit get_orderbook/get_balance (실제 API)
└── Binance get_orderbook/get_balance (실제 API)

D47: 실거래 모드 기초
├── LiveSafetyGuard (5가지 체크)
└── live_trading 설정

D48: 실거래 구현 + 레이트리밋
├── Upbit create_order/cancel_order (실제 API)
├── Binance create_order/cancel_order (실제 API)
├── HTTPClient (레이트리밋/재시도)
└── 롱런 테스트 플랜 (본 문서)
```

---

## 🧪 롱런 테스트 시나리오

### 1. Paper 모드 (기준선)

**목적:** 시뮬레이션 모드의 안정성 검증

**실행 명령:**
```bash
python -m scripts.run_arbitrage_live \
  --config configs/live/arbitrage_live_paper_example.yaml \
  --mode paper \
  --max-runtime-seconds 3600 \
  --log-level INFO
```

**테스트 계획:**

| 단계 | 시간 | 목표 | 검증 항목 |
|------|------|------|---------|
| 1 | 10분 | 초기화 안정성 | 엔진 시작, 호가 수신, 신호 생성 |
| 2 | 30분 | 거래 루프 | Trades Opened > 0, 루프 시간 안정 |
| 3 | 1시간 | 장시간 안정성 | 메모리 누수 없음, 루프 시간 일정 |

**모니터링 체크리스트:**

- ✅ 루프 시간: 평균 1000ms ± 100ms
- ✅ 메모리 사용: 증가 추세 없음
- ✅ 에러 로그: 0개
- ✅ Trades Opened: > 10
- ✅ Trades Closed: > 0

**예상 결과:**
```
Duration: 3600.0s
Loops: 3600
Trades Opened: 50-100
Trades Closed: 40-80
Total PnL: $0.00 (시뮬레이션)
Active Orders: 0-2
Avg Loop Time: 1000±50ms
```

---

### 2. Live ReadOnly 모드 (실 API 호출)

**목적:** 실 API 호출의 안정성 검증 (호가/잔고만)

**실행 명령:**
```bash
python -m scripts.run_arbitrage_live \
  --config configs/live/arbitrage_live_upbit_binance_readonly.yaml \
  --mode live_readonly \
  --max-runtime-seconds 3600 \
  --log-level INFO
```

**테스트 계획:**

| 단계 | 시간 | 목표 | 검증 항목 |
|------|------|------|---------|
| 1 | 10분 | API 연결 | 호가 수신, 잔고 조회 성공 |
| 2 | 30분 | API 안정성 | 네트워크 에러 처리, 재시도 동작 |
| 3 | 1시간 | 레이트리밋 | 429 에러 처리, 백오프 동작 |

**모니터링 체크리스트:**

- ✅ API 호출 성공률: > 99%
- ✅ 평균 응답 시간: < 500ms
- ✅ 네트워크 에러: < 1%
- ✅ 레이트리밋 히트: 0-5회
- ✅ 루프 시간: 1500-2500ms

**예상 결과:**
```
Duration: 3600.0s
Loops: 1500-2000 (느린 API 호출)
API Calls: 3000-4000 (호가 + 잔고)
Network Errors: 0-10
Rate Limit Hits: 0-5
Avg Loop Time: 1800-2000ms
```

**주의사항:**

- API 키가 없으면 `AuthenticationError` 발생
- 네트워크 불안정 시 `NetworkError` 발생
- 이 경우 로그에 기록되고 루프는 계속 진행

---

### 3. Live Trading 모드 (enabled=false)

**목적:** 실거래 코드 경로 검증 (실제 주문 없음)

**실행 명령:**
```bash
python -m scripts.run_arbitrage_live \
  --config configs/live/arbitrage_live_upbit_binance_trading.yaml \
  --mode live_trading \
  --max-runtime-seconds 3600 \
  --log-level INFO
```

**테스트 계획:**

| 단계 | 시간 | 목표 | 검증 항목 |
|------|------|------|---------|
| 1 | 10분 | 초기화 | 어댑터 초기화, Guard 초기화 |
| 2 | 30분 | Guard 동작 | 주문 차단 로그, 차단 사유 기록 |
| 3 | 1시간 | 안정성 | 에러 없이 계속 실행 |

**모니터링 체크리스트:**

- ✅ Trades Opened (엔진): > 0
- ✅ Sent Orders (실제): 0 (enabled=false)
- ✅ Blocked Orders: > 0
- ✅ Guard 차단 사유: "enabled=False" 또는 "notional exceeded"
- ✅ 루프 시간: 1500-2000ms

**예상 결과:**
```
Duration: 3600.0s
Loops: 1800-2000
Trades Opened (엔진): 50-100
Sent Orders (실제): 0 ✅
Blocked Orders: 50-100
Block Reasons:
  - "enabled=False": 30-50회
  - "notional exceeded": 20-50회
Avg Loop Time: 1800-2000ms
```

**중요:**

- `enabled=false` 상태에서는 **실제 주문이 절대 나가지 않음**
- 모든 주문 시도는 Guard에서 차단되고 로그에 기록됨
- 이것이 정상 동작입니다 ✅

---

## 📊 모니터링 가이드

### 1. 로그 모니터링

**주요 키워드:**

```bash
# 정상 로그
"[D43_LIVE] Opening trade"
"[D42_PAPER] Order created"
"[D44_RISKGUARD] Trade allowed"

# 경고 로그
"[D44_RISKGUARD] Trade rejected"
"[D47_LIVE_GUARD] Order blocked"
"[D48_HTTP_CLIENT] Rate limited"

# 에러 로그
"[D42_UPBIT] Network error"
"[D42_BINANCE] Network error"
"[D48_HTTP_CLIENT] Timeout"
```

**모니터링 명령:**

```bash
# 실시간 로그 필터링 (Linux/Mac)
python -m scripts.run_arbitrage_live ... | grep "ERROR\|WARNING"

# Windows: 로그 파일로 저장 후 검토
python -m scripts.run_arbitrage_live ... > logfile.txt 2>&1
```

### 2. 성능 메트릭

**루프 시간 분석:**

```
Paper 모드:
- 예상: 1000±100ms
- 이유: 시뮬레이션만 (네트워크 없음)

Live ReadOnly 모드:
- 예상: 1800-2000ms
- 이유: 호가 조회 (~100ms) + 잔고 조회 (~200ms) + 엔진 (~100ms)

Live Trading 모드:
- 예상: 1800-2000ms
- 이유: ReadOnly와 동일 (주문은 Guard에서 차단)
```

### 3. 에러 분류

**네트워크 에러:**
- Timeout: 재시도 후 계속 진행
- Connection Error: 재시도 후 계속 진행
- 429 (Rate Limit): exponential backoff 후 재시도

**인증 에러:**
- API 키 부족: 루프 종료 (또는 로그만 남기고 계속)
- 서명 실패: 루프 종료

**비즈니스 에러:**
- 잔고 부족: Guard에서 차단
- 심볼 미지원: Guard에서 차단
- 일일 손실 초과: Guard에서 차단 + 세션 종료

---

## 🚀 실거래 전 체크리스트

**Live Trading 모드에서 `enabled=true`로 변경하기 전에:**

### 1. 설정 검토

```yaml
live_trading:
  enabled: false  # ⚠️ 반드시 false 상태에서 테스트
  dry_run_scale: 0.01  # 1%부터 시작
  allowed_symbols:
    - KRW-BTC  # 테스트할 심볼만
  min_account_balance: 50.0
  max_daily_loss: 20.0
  max_notional_per_trade: 50.0
```

### 2. API 키 확인

```bash
# 환경변수 설정 확인
echo $UPBIT_API_KEY
echo $BINANCE_API_KEY

# 값이 있는지 확인
# (절대 출력하지 말 것!)
```

### 3. 계좌 잔고 확인

- Upbit: 최소 100,000 KRW
- Binance: 최소 100 USDT

### 4. 롱런 테스트 완료

- Paper 모드: 1시간 이상 ✅
- Live ReadOnly: 1시간 이상 ✅
- Live Trading (enabled=false): 1시간 이상 ✅

### 5. 로그 검토

- 에러 없음 ✅
- Guard 차단 정상 동작 ✅
- 루프 시간 안정 ✅

---

## 📈 단계적 확대 전략

**enabled=true로 변경 후:**

### 1단계: 매우 보수적 (1시간)

```yaml
dry_run_scale: 0.01  # 1%
max_notional_per_trade: 10.0  # 매우 작음
allowed_symbols:
  - KRW-BTC  # 한 심볼만
```

**목표:**
- 실제 주문 1-5개 발생
- 모두 성공
- 손실 최소화

### 2단계: 보수적 (4시간)

```yaml
dry_run_scale: 0.05  # 5%
max_notional_per_trade: 50.0
allowed_symbols:
  - KRW-BTC
  - BTCUSDT
```

**목표:**
- 실제 주문 10-20개 발생
- 성공률 > 95%
- 수익성 검증

### 3단계: 표준 (12시간)

```yaml
dry_run_scale: 0.1  # 10%
max_notional_per_trade: 100.0
allowed_symbols:
  - KRW-BTC
  - BTCUSDT
```

**목표:**
- 실제 주문 50-100개 발생
- 성공률 > 98%
- 안정성 검증

### 4단계: 정상 (24시간+)

```yaml
dry_run_scale: 1.0  # 100%
max_notional_per_trade: 1000.0
allowed_symbols:
  - KRW-BTC
  - BTCUSDT
  - (추가 심볼)
```

**목표:**
- 실제 주문 100+개 발생
- 성공률 > 99%
- 수익성 검증

---

## ⚠️ 위험 관리

### 1. 최대 손실 제한

```yaml
max_daily_loss: 20.0  # USD
```

- 일일 손실이 20 USD를 초과하면 **자동 세션 종료**
- 다음 날 새로 시작

### 2. 계좌 잔고 모니터링

```yaml
min_account_balance: 50.0  # USD
```

- 잔고가 50 USD 미만이면 **주문 차단**
- 추가 자금 입금 필요

### 3. 주문 규모 제한

```yaml
max_notional_per_trade: 50.0  # USD
```

- 한 번의 주문이 50 USD를 초과하면 **차단**
- 엔진 신호가 크더라도 축소됨

---

## 📞 문제 해결

### 문제: 주문이 나가지 않음

**확인 사항:**
1. `enabled=true`인가?
2. 계좌 잔고 > `min_account_balance`?
3. 심볼이 `allowed_symbols`에 있는가?
4. 주문 규모 < `max_notional_per_trade`?

**로그 확인:**
```
[D47_LIVE_GUARD] Order blocked: ...
```

### 문제: 네트워크 에러 반복

**확인 사항:**
1. 인터넷 연결 안정?
2. API 엔드포인트 접근 가능?
3. 방화벽/프록시 설정?

**로그 확인:**
```
[D48_HTTP_CLIENT] Timeout
[D42_UPBIT] Network error
```

### 문제: 레이트리밋 에러

**확인 사항:**
1. 다른 프로세스가 같은 API 키 사용?
2. 루프 시간이 너무 짧음?

**해결:**
```yaml
rate_limit:
  max_requests_per_sec: 3  # 5에서 3으로 감소
  max_retry: 5  # 3에서 5로 증가
  base_backoff_seconds: 1.0  # 0.5에서 1.0으로 증가
```

---

## 📊 결과 분석 템플릿

**1시간 테스트 후:**

```
테스트 모드: [Paper / Live ReadOnly / Live Trading]
테스트 시간: [시작 시간] ~ [종료 시간]
총 소요 시간: [시간]

성능:
- 루프 수: [개]
- 평균 루프 시간: [ms]
- 최대 루프 시간: [ms]
- 최소 루프 시간: [ms]

거래:
- 신호 생성: [개]
- 주문 발행: [개]
- 주문 성공: [개]
- 주문 실패: [개]
- 성공률: [%]

에러:
- 네트워크 에러: [개]
- 인증 에러: [개]
- 기타 에러: [개]

결론:
- 안정성: [우수 / 양호 / 개선 필요]
- 다음 단계: [진행 / 재테스트 / 설정 조정]
```

---

## 🎯 결론

D48 롱런 테스트 플랜은 **3단계 검증 프로세스**를 제공합니다:

1. **Paper 모드**: 시뮬레이션 안정성 ✅
2. **Live ReadOnly**: 실 API 안정성 ✅
3. **Live Trading (enabled=false)**: 실거래 코드 경로 ✅

각 단계를 충분히 테스트한 후, 단계적으로 `enabled=true`로 확대합니다.

**중요:** 실거래는 항상 **매우 작은 규모**에서 시작하고, 충분한 검증 후 확대하세요.

---

**작성자:** Cascade AI  
**작성일:** 2025-11-17  
**상태:** ✅ 완료 (플랜 문서)
