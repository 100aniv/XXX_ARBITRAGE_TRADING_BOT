# D16 Live Arbitrage Core Architecture

## 📋 개요

D16은 D15 고성능 모듈 위에 **실거래 기능을 추가**하는 단계입니다.

**핵심 목표:**
- Upbit/Binance 실거래 루프 구축
- D15 모듈 (변동성, 포트폴리오, 리스크) 자동 연동
- 안전 장치 (LiveGuard) 통합
- 실시간 상태 관리 (Redis)
- FastAPI 백엔드 제공

---

## 🏗️ 아키텍처 다이어그램

```
┌─────────────────────────────────────────────────────────────────┐
│                    D16 Live Arbitrage Core                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  LivePriceCollector (data/live_prices.py)               │   │
│  │  - Upbit WebSocket (KRW-BTC, KRW-ETH, ...)             │   │
│  │  - Binance WebSocket (BTCUSDT, ETHUSDT, ...)           │   │
│  │  - 스프레드 계산 (bid-ask)                              │   │
│  └──────────────────────────────────────────────────────────┘   │
│         ▲                                                         │
│         │ (실시간 가격)                                          │
│         │                                                         │
│  ┌──────┴──────────────────────────────────────────────────┐   │
│  │  LiveTrader (arbitrage/live_trader.py)                 │   │
│  │  - 차익 신호 생성                                       │   │
│  │  - D15 모듈 연동:                                       │   │
│  │    - VolatilityPredictor (포지션 크기)                 │   │
│  │    - PortfolioOptimizer (노출도 조절)                  │   │
│  │    - QuantitativeRiskManager (손실 제한)              │   │
│  │  - 주문 실행 (Upbit/Binance)                           │   │
│  │  - 포지션 관리                                          │   │
│  └──────────────────────────────────────────────────────────┘   │
│         ▲                                                         │
│         │ (상태 저장)                                            │
│         │                                                         │
│  ┌──────┴──────────────────────────────────────────────────┐   │
│  │  StateManager (arbitrage/state_manager.py)             │   │
│  │  - Redis 기반 실시간 상태 관리                         │   │
│  │  - 가격, 신호, 주문, 포지션, 실행 결과 저장           │   │
│  │  - 메트릭 저장/조회                                    │   │
│  └──────────────────────────────────────────────────────────┘   │
│         ▲                                                         │
│         │ (상태 조회)                                            │
│         │                                                         │
│  ┌──────┴──────────────────────────────────────────────────┐   │
│  │  FastAPI Server (api/server.py)                        │   │
│  │  - /health: 헬스 체크                                  │   │
│  │  - /metrics/live: 실시간 메트릭                        │   │
│  │  - /positions: 포지션 조회                             │   │
│  │  - /signals: 신호 조회                                 │   │
│  │  - /orders: 주문 조회                                  │   │
│  │  - /executions: 실행 결과 조회                         │   │
│  │  - WebSocket: 실시간 업데이트                          │   │
│  └──────────────────────────────────────────────────────────┘   │
│         ▲                                                         │
│         │ (HTTP/WebSocket)                                       │
│         │                                                         │
│  ┌──────┴──────────────────────────────────────────────────┐   │
│  │  Dashboard (대시보드)                                  │   │
│  │  - 실시간 메트릭 시각화                                │   │
│  │  - 포지션 모니터링                                     │   │
│  │  - 신호/실행 로그                                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  SafetyModule (liveguard/safety.py)                    │   │
│  │  - 포지션 크기 제한                                    │   │
│  │  - 일일/누적 손실 제한                                 │   │
│  │  - 거래 빈도 제한                                      │   │
│  │  - 슬리피지 검사                                       │   │
│  │  - 회로차단기                                          │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Exchange Adapters (arbitrage/exchange/)               │   │
│  │  - UpbitExchange (REST + WebSocket)                    │   │
│  │  - BinanceExchange (REST + WebSocket)                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📁 파일 구조

```
arbitrage/
    types.py                    # 공통 타입 정의
    live_trader.py              # 실거래 루프
    state_manager.py            # Redis 상태 관리
    exchange/
        __init__.py
        upbit.py                # Upbit 어댑터
        binance.py              # Binance 어댑터

data/
    live_prices.py              # 실시간 가격 수집

liveguard/
    __init__.py
    safety.py                   # 안전 장치
    risk_limits.py              # 리스크 제한

api/
    __init__.py
    server.py                   # FastAPI 백엔드

tests/
    test_d16_types.py
    test_d16_safety.py
    test_d16_state_manager.py
    test_d16_exchange.py
```

---

## 🔄 실거래 루프 흐름

```
1. 가격 수집
   ├─ Upbit WebSocket 구독 (KRW-BTC, KRW-ETH, ...)
   ├─ Binance WebSocket 구독 (BTCUSDT, ETHUSDT, ...)
   └─ 실시간 가격 캐싱

2. 신호 생성
   ├─ 스프레드 계산 (sell_bid - buy_ask)
   ├─ 수익성 검사 (spread_pct > min_spread_pct)
   └─ 신호 저장 (Redis)

3. 안전 검사
   ├─ 포지션 크기 제한
   ├─ 일일 손실 제한
   ├─ 거래 빈도 제한
   ├─ 슬리피지 검사
   └─ 회로차단기

4. 주문 실행
   ├─ 매수 주문 (buy_exchange)
   ├─ 매도 주문 (sell_exchange)
   └─ 실행 결과 저장

5. 포지션 관리
   ├─ 포지션 상태 업데이트
   ├─ 손절/익절 로직
   └─ 포지션 정리

6. 메트릭 업데이트
   ├─ 잔액, 포지션, 주문 수
   ├─ 손실, 거래 수
   └─ 하트비트 전송
```

---

## 🔐 D15 모듈 연동

### 변동성 모델 (VolatilityPredictor)

```python
# 포지션 크기 계산
volatility = volatility_predictor.predict_batch(recent_prices)
position_size = calculate_position_size(volatility, total_balance)
```

### 포트폴리오 최적화 (PortfolioOptimizer)

```python
# 노출도 조절
returns = portfolio_optimizer.add_returns_batch(symbol_returns)
weights = portfolio_optimizer.get_optimal_weights(symbols)
adjusted_position = position_size * weights[symbol]
```

### 정량 리스크 (QuantitativeRiskManager)

```python
# 손실 제한
risk_metrics = risk_manager.calculate_risk_metrics(returns)
max_loss = total_balance * risk_metrics.var_95
if current_loss > max_loss:
    circuit_breaker_activated()
```

---

## 🛡️ 안전 장치 (LiveGuard)

### 포지션 크기 제한

```
max_position_size = 1,000,000 KRW
```

### 일일 손실 제한

```
max_daily_loss = 500,000 KRW
```

### 거래 빈도 제한

```
max_trades_per_hour = 100
max_trades_per_day = 1,000
```

### 회로차단기

```
circuit_breaker_threshold = 5% (손실률)
circuit_breaker_cooldown = 300초
```

---

## 📊 Redis 데이터 스키마

### 가격 (TTL: 60초)

```
arbitrage:prices:{exchange}:{symbol}
  - bid: float
  - ask: float
  - mid: float
  - timestamp: ISO8601
```

### 신호 (TTL: 300초)

```
arbitrage:signal:{symbol}
  - symbol: str
  - buy_exchange: str
  - sell_exchange: str
  - buy_price: float
  - sell_price: float
  - spread: float
  - spread_pct: float
  - timestamp: ISO8601
```

### 주문 (TTL: 86400초)

```
arbitrage:orders:{order_id}
  - order_id: str
  - exchange: str
  - symbol: str
  - side: str (buy/sell)
  - quantity: float
  - price: float
  - status: str
  - filled_quantity: float
  - fill_rate: float
  - created_at: ISO8601
  - updated_at: ISO8601
```

### 포지션 (TTL: 86400초)

```
arbitrage:positions:{symbol}
  - symbol: str
  - quantity: float
  - entry_price: float
  - current_price: float
  - side: str (buy/sell)
  - pnl: float
  - pnl_pct: float
  - timestamp: ISO8601
```

### 실행 결과 (TTL: 86400초)

```
arbitrage:execution:{symbol}:{timestamp}
  - symbol: str
  - buy_order_id: str
  - sell_order_id: str
  - buy_price: float
  - sell_price: float
  - quantity: float
  - gross_pnl: float
  - net_pnl: float
  - fees: float
  - pnl_pct: float
  - timestamp: ISO8601
```

### 메트릭 (TTL: 300초)

```
arbitrage:metrics:live
  - total_balance: float
  - available_balance: float
  - positions_count: int
  - orders_count: int
  - daily_loss: float
  - total_loss: float
  - trades_today: int
```

### 하트비트 (TTL: 60초)

```
arbitrage:heartbeat:{component}
  - timestamp: ISO8601
```

---

## 🔌 API 엔드포인트

### 헬스 체크

```
GET /health
```

### 메트릭

```
GET /metrics/live
```

### 포지션

```
GET /positions
GET /positions/{symbol}
```

### 신호

```
GET /signals
GET /signals/{symbol}
```

### 주문

```
GET /orders
GET /orders/{order_id}
```

### 실행 결과

```
GET /executions?symbol={symbol}&limit={limit}
```

### WebSocket

```
WS /ws/metrics
WS /ws/signals
```

---

## 🚀 실행 방법

### 1. 환경 설정

```bash
# .env 파일 생성
cp infra/.env.example infra/.env

# 편집
UPBIT_API_KEY=your_key
UPBIT_SECRET_KEY=your_secret
BINANCE_API_KEY=your_key
BINANCE_SECRET_KEY=your_secret
LIVE_MODE=false  # paper mode
```

### 2. Docker Compose 실행

```bash
cd infra
docker-compose up -d
```

### 3. 실거래 루프 시작

```bash
python -m arbitrage.live_trader
```

### 4. API 서버 시작

```bash
python -m api.server
```

### 5. 대시보드 접속

```
http://localhost:8001
```

---

## 📈 성능 목표

| 항목 | 목표 |
|------|------|
| 가격 수집 지연 | < 100ms |
| 신호 생성 지연 | < 50ms |
| 주문 실행 지연 | < 500ms |
| 메트릭 업데이트 | 1초 |
| API 응답 시간 | < 100ms |

---

## 🔗 참고 문서

- `docs/ROLE.md` - 프로젝트 규칙
- `docs/D16_LIVE_API.md` - API 상세 문서
- `docs/D16_LIVE_TRADING_LOOP.md` - 거래 루프 상세
- `docs/D16_REDIS_SCHEMA.md` - Redis 스키마 상세
