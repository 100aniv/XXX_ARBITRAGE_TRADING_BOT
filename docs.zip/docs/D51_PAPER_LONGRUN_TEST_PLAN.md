# D51 Paper Long-run Test Plan

**작성일:** 2025-11-17  
**상태:** ✅ 정의 완료

---

## 📋 Executive Summary

D51은 **Paper 모드 롱런 테스트 플랜**을 정식으로 정의하고, **실행 기반**을 구축합니다.

**3가지 시나리오:**
- **S1 (1시간 미니 롱런):** 개발·버그 재현용
- **S2 (6시간 중기 롱런):** 야간 테스트용
- **S3 (24시간 롱런):** 실제 "준-운영" 검증용

---

## 🎯 목표

1. **시스템 안정성 검증**
   - 루프 시간 안정성 (평균, 분산, 최대값)
   - 메트릭 수집 오버헤드 확인
   - 메모리 누수 여부

2. **버그/이상 징후 탐지**
   - 스냅샷 None 발생 패턴
   - Guard 과다발동 여부
   - 체결 신호 이상 (0에 가까운 상태 지속)
   - REST API 호출 실패 패턴

3. **성능 기준선 확립**
   - 정상 루프 시간 범위
   - 정상 스프레드 분포
   - 정상 체결 빈도

---

## 📊 시나리오 정의

### S1: 1시간 미니 롱런 (개발·버그 재현용)

**목적:**
- 빠른 피드백 루프 (개발 중 버그 재현)
- 간단한 이상 징후 탐지

**입력:**
```yaml
config: configs/live/arbitrage_live_paper_example.yaml
data_source: "rest"  # 강제
duration: 60 분
mode: "paper"
```

**환경:**
- 개발 머신 (로컬)
- 네트워크: 안정적 (LAN)
- 부하: 낮음 (다른 프로세스 최소)

**관찰 메트릭:**
- 루프 시간: 평균 ±10% 범위 내
- 스냅샷 None: 0회
- Guard 발동: 정상 범위 (예: 0~2회)
- 체결 신호: 최소 1회 이상

**테스트 실패 기준:**
- 루프 시간 평균 > 1500ms
- 스냅샷 None > 5회
- Guard SESSION_STOP 발동
- 에러 로그 > 10개

**예상 결과:**
```
Duration: 60.0s
Loops: 60
Trades Opened: 2~5
Avg Loop Time: 1000±100ms
Errors: 0
```

---

### S2: 6시간 중기 롱런 (야간 테스트용)

**목적:**
- 장시간 안정성 검증
- 메모리 누수 탐지
- 시간대별 성능 변화 관찰

**입력:**
```yaml
config: configs/live/arbitrage_live_paper_example.yaml
data_source: "rest"  # 강제
duration: 360 분 (6시간)
mode: "paper"
```

**환경:**
- 개발/테스트 서버
- 네트워크: 안정적
- 부하: 중간 (다른 테스트 병행 가능)

**관찰 메트릭:**
- 루프 시간: 평균 ±15% 범위 내 (시간대별 변화 추적)
- 스냅샷 None: 0~10회
- Guard 발동: 정상 범위 (예: 0~5회)
- 체결 신호: 최소 10회 이상
- 메모리 사용량: 선형 증가 없음

**테스트 실패 기준:**
- 루프 시간 평균 > 1500ms 또는 증가 추세
- 스냅샷 None > 50회
- Guard SESSION_STOP 발동
- 에러 로그 > 50개
- 메모리 사용량 > 500MB 증가

**예상 결과:**
```
Duration: 360.0s
Loops: 360
Trades Opened: 10~20
Avg Loop Time: 1000±150ms
Errors: 0~5
Memory Delta: < 100MB
```

---

### S3: 24시간 롱런 (실제 "준-운영" 검증용)

**목적:**
- 실제 운영 환경 시뮬레이션
- 장시간 안정성 최종 검증
- 일일 사이클 성능 변화 관찰

**입력:**
```yaml
config: configs/live/arbitrage_live_paper_example.yaml
data_source: "rest"  # 강제
duration: 1440 분 (24시간)
mode: "paper"
```

**환경:**
- 운영 서버 (또는 운영 환경 시뮬레이션)
- 네트워크: 안정적 (또는 간헐적 지연 시뮬레이션)
- 부하: 중간~높음

**관찰 메트릭:**
- 루프 시간: 평균 ±20% 범위 내 (시간대별 변화 추적)
- 스냅샷 None: 0~50회
- Guard 발동: 정상 범위 (예: 0~10회)
- 체결 신호: 최소 50회 이상
- 메모리 사용량: 선형 증가 없음
- 일일 사이클: 시간대별 성능 변화 패턴 분석

**테스트 실패 기준:**
- 루프 시간 평균 > 1500ms 또는 증가 추세
- 스냅샷 None > 200회
- Guard SESSION_STOP 발동
- 에러 로그 > 200개
- 메모리 사용량 > 500MB 증가
- 특정 시간대 성능 급락 (예: 루프 시간 > 3000ms)

**예상 결과:**
```
Duration: 1440.0s
Loops: 1440
Trades Opened: 50~100
Avg Loop Time: 1000±200ms
Errors: 0~20
Memory Delta: < 200MB
Hourly Pattern: 안정적
```

---

## 🔍 관찰할 메트릭/로그 항목

### 1. 루프 시간 (Loop Time)

**메트릭:**
- `loop_time_ms`: 각 루프 실행 시간
- `loop_time_avg_ms`: 평균 루프 시간
- `loop_time_max_ms`: 최대 루프 시간
- `loop_time_min_ms`: 최소 루프 시간

**정상 범위:**
- 평균: 950~1050ms (1초 ±5%)
- 최대: < 2000ms
- 분산: < 200ms

**이상 징후:**
- 평균 > 1500ms (루프 시간 폭주)
- 최대 > 3000ms (간헐적 지연)
- 분산 > 500ms (불안정)

---

### 2. 스냅샷 상태 (Snapshot Status)

**메트릭:**
- `snapshot_none_count`: None 반환 횟수
- `snapshot_invalid_count`: 유효하지 않은 데이터 횟수

**정상 범위:**
- None: 0회 (또는 매우 드물게)
- Invalid: 0회

**이상 징후:**
- None > 10회 (REST API 호출 실패 패턴)
- Invalid > 5회 (데이터 파싱 오류)

---

### 3. 체결 신호 (Trades Opened)

**메트릭:**
- `trades_opened_total`: 누적 체결 수
- `trades_opened_recent`: 최근 1분 체결 수
- `trades_opened_rate`: 체결 빈도 (회/시간)

**정상 범위:**
- 1시간: 2~5회
- 6시간: 10~20회
- 24시간: 50~100회

**이상 징후:**
- 1시간 이상 0회 (신호 생성 불가)
- 급격한 증가 (> 10회/시간)

---

### 4. Guard 발동 (Risk Guard Events)

**메트릭:**
- `guard_trade_rejected_count`: 거래 거부 횟수
- `guard_session_stop_count`: 세션 중지 횟수
- `guard_daily_loss_usd`: 누적 손실

**정상 범위:**
- Trade Rejected: 0~5회 (정상)
- Session Stop: 0회 (정상)
- Daily Loss: 0 USD (Paper 모드)

**이상 징후:**
- Trade Rejected > 10회 (과다 거부)
- Session Stop > 0회 (손실 한도 도달)

---

### 5. 에러 로그 (Error Logs)

**추적 항목:**
- `[ERROR]` 로그 개수
- `[WARNING]` 로그 개수
- 에러 유형 분류 (HTTP, Parsing, Logic 등)

**정상 범위:**
- ERROR: 0개
- WARNING: 0~5개

**이상 징후:**
- ERROR > 10개
- WARNING > 20개

---

## 📋 롱런 후 점검 항목

### 1. 실행 환경 확인
- [ ] 시작 시간 / 종료 시간 기록
- [ ] 실행 머신 정보 (CPU, 메모리, OS)
- [ ] 네트워크 상태 (지연, 패킷 손실)
- [ ] 다른 프로세스 부하 여부

### 2. 메트릭 수집 확인
- [ ] MetricsCollector 정상 동작
- [ ] 로그 파일 생성 여부
- [ ] 메트릭 데이터 완전성

### 3. 성능 분석
- [ ] 루프 시간 분포 (평균, 최대, 분산)
- [ ] 루프 시간 추이 (시간대별 변화)
- [ ] 메모리 사용량 추이

### 4. 기능 검증
- [ ] 체결 신호 생성 여부
- [ ] Guard 정상 동작
- [ ] 스냅샷 생성 안정성

### 5. 버그/이상 징후
- [ ] 에러 로그 분석
- [ ] 경고 로그 분석
- [ ] 비정상 패턴 탐지

---

## 🛠️ 실행 방법

### S1 (1시간 미니 롱런)

```bash
python -m scripts.run_paper_longrun \
  --config configs/live/arbitrage_live_paper_example.yaml \
  --scenario S1 \
  --duration-minutes 60
```

**예상 실행 시간:** 1분 (시뮬레이션 모드)

### S2 (6시간 중기 롱런)

```bash
python -m scripts.run_paper_longrun \
  --config configs/live/arbitrage_live_paper_example.yaml \
  --scenario S2 \
  --duration-minutes 360
```

**예상 실행 시간:** 6분 (시뮬레이션 모드)

### S3 (24시간 롱런)

```bash
python -m scripts.run_paper_longrun \
  --config configs/live/arbitrage_live_paper_example.yaml \
  --scenario S3 \
  --duration-minutes 1440
```

**예상 실행 시간:** 24분 (시뮬레이션 모드)

---

## 📊 결과 분석

### 결과 파일 위치

```
reports/
├── D51_longrun_S1_20251117_233000.txt
├── D51_longrun_S2_20251117_233000.txt
└── D51_longrun_S3_20251117_233000.txt
```

### 분석 도구 사용

```bash
python -m arbitrage.monitoring.longrun_analyzer \
  --log-file reports/D51_longrun_S1_20251117_233000.txt \
  --output-report reports/D51_longrun_S1_analysis.txt
```

---

## ⚠️ 주의사항

### 1. data_source 고정

- **반드시 `data_source="rest"` 사용**
- WebSocket 모드는 D52 "WS Long-run Validation"에서 별도 정의

### 2. 기본값 유지

- 엔진 파라미터 변경 금지
- Guard 규칙 변경 금지
- 전략 로직 변경 금지

### 3. 환경 통제

- 롱런 중 다른 프로세스 최소화
- 네트워크 상태 안정적 유지
- 시스템 리소스 충분히 확보

### 4. 결과 기록

- 모든 롱런 결과 저장
- 이상 징후 발견 시 즉시 기록
- 버그 재현 시 config/로그 보관

---

## 📈 성공 기준

### S1 (1시간)
- ✅ 루프 시간 평균 < 1500ms
- ✅ 스냅샷 None = 0회
- ✅ 에러 로그 = 0개
- ✅ 체결 신호 ≥ 1회

### S2 (6시간)
- ✅ 루프 시간 평균 < 1500ms
- ✅ 루프 시간 증가 추세 없음
- ✅ 스냅샷 None < 10회
- ✅ 에러 로그 < 10개
- ✅ 메모리 누수 없음

### S3 (24시간)
- ✅ 루프 시간 평균 < 1500ms
- ✅ 루프 시간 증가 추세 없음
- ✅ 스냅샷 None < 50회
- ✅ 에러 로그 < 50개
- ✅ 메모리 누수 없음
- ✅ 일일 사이클 패턴 안정적

---

## 🚀 다음 단계

### D52: WS Long-run Validation
- WebSocket 모드 롱런 테스트
- 재연결 정책 검증
- 메시지 손실 처리

### D53: Performance Tuning
- 루프 시간 최적화
- 메모리 사용량 최적화
- 체결 신호 개선

---

**D51 Paper Long-run Test Plan 정의 완료.** ✅

**작성자:** Cascade AI  
**작성일:** 2025-11-17  
**상태:** ✅ 정의 완료
